DNS Check Application

